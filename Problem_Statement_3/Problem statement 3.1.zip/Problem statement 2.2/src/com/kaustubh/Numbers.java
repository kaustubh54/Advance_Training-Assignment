package com.kaustubh;

import java.util.Scanner;

class Numbers {
  public static void main(String[] args) {

    int i = 1, n = 13, firstTerm , secondTerm;
    Scanner sc=new Scanner(System.in);
	System.out.println("Enter two numbers");
	firstTerm=sc.nextInt();
	secondTerm =sc.nextInt();
    System.out.println("Print the series till " + n + " terms:");

    while (i <= n) {
      System.out.print(firstTerm + ", ");

      int nextTerm = firstTerm + secondTerm;
      firstTerm = secondTerm;
      secondTerm = nextTerm;

      i++;
    }
  }
}