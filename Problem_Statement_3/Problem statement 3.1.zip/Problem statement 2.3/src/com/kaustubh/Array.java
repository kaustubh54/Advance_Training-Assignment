package com.kaustubh;

public class Array {
	public static void main(String[] args) {
		int A[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
	int sum = 0;
	int lengthofArray = A.length;
	for(int i=0;i<14;i++) {
		 sum = sum + A[i];
		

	}
	System.out.println(sum);
	int position = 15;
	for(int i=0;i<A.length;i++){
	if(i==position){
	        A[i] = sum;
	        System.out.println(A[i]);
	}
}
	}}