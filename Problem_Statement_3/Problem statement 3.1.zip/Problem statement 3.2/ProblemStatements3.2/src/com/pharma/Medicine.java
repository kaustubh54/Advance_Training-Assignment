package com.pharma;

public class Medicine
{
public void displayLabel()
{
System.out.println("Company : KN Pharnasuticals");
System.out.println("Address : Mumbai");
}
}
class Tablet extends Medicine
{
public void displayLabel()
{
System.out.println("Get the correct medicine");
}
}
class Syrup extends Medicine
{
public void displayLabel()
{
System.out.println("medicine should be taken carefully");
}
}
class Ointment extends Medicine
{
public void displayLabel()
{
System.out.println("for external use only");
}
}