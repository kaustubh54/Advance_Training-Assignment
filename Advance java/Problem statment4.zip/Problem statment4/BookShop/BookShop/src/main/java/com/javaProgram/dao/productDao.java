package com.javaProgram.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.javaProgram.dbutil.JDBCConnector;
import com.javaProgram.entity.product;

public class productDao {

    public static List<product> getAllProduct(){  
	List<product> list=new ArrayList<product>();  
    
    try{  
        Connection con=JDBCConnector.initializeDatabase(); 
        PreparedStatement ps=con.prepareStatement("select * from book");  
        ResultSet rs=ps.executeQuery();  
        while(rs.next()){  
            product p=new product();  
            p.setBook_id(rs.getInt(1));  
            p.setBook_Name(rs.getString(2));  
            p.setAuthor(rs.getString(3));  
            p.setPrice(rs.getInt(4));  
            
            list.add(p);  
        }  
      }catch (Exception e) {
		
	}
	return list;
}
}
