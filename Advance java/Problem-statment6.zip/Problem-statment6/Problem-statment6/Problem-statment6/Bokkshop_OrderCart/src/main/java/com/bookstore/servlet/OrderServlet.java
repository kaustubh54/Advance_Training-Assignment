package com.bookstore.servlet;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bookstore.dao.UserDao;
import com.bookstore.jdbcConnection.*;
import com.bookstore.entity.Orders;
import com.bookstore.entity.User;
import com.bookstore.jdbcConnection.JDBCConnector;

/**
 * Servlet implementation class OrderServlet
 */
public class OrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			
		Connection con;
		PrintWriter out=response.getWriter();
		String Custname=request.getParameter("cname");
		String add=request.getParameter("address");
		int no=Integer.parseInt(request.getParameter("no"));
		int qau=Integer.parseInt(request.getParameter("qau"));
		Orders order=new Orders(add, no, Custname);
		UserDao dao = new UserDao();
		
		con=JDBCConnector.initializeDatabase();
		dao.order(order);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
