package com.javaProgram.entity;

public class product {
	
	String Book_Name;
	String Author;
	int price;
	int Book_id;
	
	
	
	public product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public product(String book_Name, String author, int price, int book_id) {
		super();
		Book_Name = book_Name;
		Author = author;
		this.price = price;
		Book_id = book_id;
	}
	public String getBook_Name() {
		return Book_Name;
	}
	public void setBook_Name(String book_Name) {
		Book_Name = book_Name;
	}
	public String getAuthor() {
		return Author;
	}
	public void setAuthor(String author) {
		Author = author;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getBook_id() {
		return Book_id;
	}
	public void setBook_id(int book_id) {
		Book_id = book_id;
	}

}
