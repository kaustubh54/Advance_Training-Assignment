package com.training;

public class StringDemo {

		public static void main(String[] args) {
			
		
		String txt= "JAVA is Simple";
		
		System.out.println(txt.toUpperCase()); //UpperCase
		
		System.out.println(txt.toLowerCase()); //LowerCase
		
		//first word to display
		
		  char c[] = ((java.lang.String) txt).toCharArray();
	      for (int i=0; i < c.length; i++) {
	         // Logic to implement first character of each word in a string
	         if(c[i] != ' ' && (i == 0 || c[i-1] == ' ')) {
	            System.out.println(c[i]);
	         }
	      }
		//reverse all words
	      String strWords[] = txt.split("\\s");
	      String rev = "";
	      for(String sw : strWords) {
	      StringBuilder sb = new StringBuilder(sw);
	      sb.reverse();
	      rev += sb.toString() + " ";
	      }
	      System.out.println( rev.trim());
		
		//Total Length
		System.out.println("length of string " + txt.replace(" ", "").length());
	
		
	}
	}
		